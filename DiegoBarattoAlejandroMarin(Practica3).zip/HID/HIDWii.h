/******************************************************************
*
*	Wiimote for C++
*
*	Copyright (C) Satoshi Konno 2007
*
*	File:	Wiimote.cpp
*
******************************************************************/

#include "UsbHID.h"
#include "HID.h"


#pragma once
class HID : public BaseHID
{
private:
	UsbHID* usb;
	static const int VENDER_ID;
	static const int PRODUCT_ID;

	bool vib;

	bool LeeMando();
	void EscribeMando();
	void Mando2HID();
	void Calibra() {}

public:
	HID(float t) :BaseHID(t) { usb = new UsbHID(); open(); };
	~HID()
	{
		if (vib)
		{
			unsigned char pause[2];
			pause[0] = 21;
			pause[1] = 0;

			usb->write(pause, 2);
		}

		delete usb;
	};

	////////////////////////////////////////////////
	//	Functions
	////////////////////////////////////////////////

	bool open();

	////////////////////////////////////////////////
	//	LED
	////////////////////////////////////////////////

	bool setLEDs(bool led1, bool led2, bool led3, bool led4);

	////////////////////////////////////////////////
	//	Button
	////////////////////////////////////////////////

	bool IsAPressed()
	{
		return usb->IsButtonPressed(2, 0x08);
	}

	bool IsBPressed()
	{
		return usb->IsButtonPressed(2, 0x04);
	}

	bool IsOnePressed()
	{
		return usb->IsButtonPressed(2, 0x02);
	}

	bool IsTwoPressed()
	{
		return usb->IsButtonPressed(2, 0x01);
	}

	bool IsLeftPressed()
	{
		return usb->IsButtonPressed(1, 0x01);
	}

	bool IsRightPressed()
	{
		return usb->IsButtonPressed(1, 0x02);
	}

	bool IsUpPressed()
	{
		return usb->IsButtonPressed(1, 0x08);
	}

	bool IsDownPressed()
	{
		return usb->IsButtonPressed(1, 0x04);
	}

	bool IsMinusPressed()
	{
		return usb->IsButtonPressed(2, 0x10);
	}

	bool IsPlusPressed()
	{
		return usb->IsButtonPressed(1, 0x10);
	}

	bool IsHomePressed()
	{
		return usb->IsButtonPressed(2, 0x80);
	}

	////////////////////////////////////////////////
	//	Motion
	////////////////////////////////////////////////

	unsigned char getXMotion()
	{
		return usb->getInputByte(3);
	}

	unsigned char getYMotion()
	{
		return usb->getInputByte(4);
	}

	unsigned char getZMotion()
	{
		return usb->getInputByte(5);
	}


	void setRumble();
};

