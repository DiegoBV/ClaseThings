#include "HIDWii.h"

const int HID::VENDER_ID = 0x057E;
const int HID::PRODUCT_ID = 0x0306;

bool HID::LeeMando()
{
	return usb->read();
}

void HID::EscribeMando()
{
	setRumble();
}

void HID::Mando2HID()
{
	if (IsHomePressed()) 		wButtons |= XINPUT_GAMEPAD_BACK; //funciones de los diferentes botones
	else 	wButtons &= ~XINPUT_GAMEPAD_BACK; //(home)
	
	if (IsAPressed())		wButtons |= XINPUT_GAMEPAD_A;
	else  	wButtons &= ~XINPUT_GAMEPAD_A; //(boton A)
	
	if (IsBPressed()) wButtons |= XINPUT_GAMEPAD_B;
	else wButtons &= ~XINPUT_GAMEPAD_B; //(boton B)
	
	if (IsOnePressed()) wButtons |= XINPUT_GAMEPAD_LEFT_SHOULDER;
	else wButtons &= ~XINPUT_GAMEPAD_LEFT_SHOULDER; //(boton 1)

	if (IsTwoPressed()) wButtons |= XINPUT_GAMEPAD_RIGHT_SHOULDER;
	else wButtons &= ~XINPUT_GAMEPAD_RIGHT_SHOULDER; //(boton 2)

	//Cruz de direcciones
	IsUpPressed() ? wButtons |= XINPUT_GAMEPAD_DPAD_UP : wButtons &= ~XINPUT_GAMEPAD_DPAD_UP;
	IsDownPressed() ? wButtons |= XINPUT_GAMEPAD_DPAD_DOWN : wButtons &= ~XINPUT_GAMEPAD_DPAD_DOWN;
	IsLeftPressed() ? wButtons |= XINPUT_GAMEPAD_DPAD_LEFT : wButtons &= ~XINPUT_GAMEPAD_DPAD_LEFT;
	IsRightPressed() ? wButtons |= XINPUT_GAMEPAD_DPAD_RIGHT : wButtons &= ~XINPUT_GAMEPAD_DPAD_RIGHT;

	
	//Normalizamos Joys
	fThumbLX = (float)(getXMotion() - 0x80) / 25.0;  // +g=24/127 [-1.0,1.0]
	fThumbLY = -(float)(getYMotion() - 0x80) / 25.0; //[-1.0,1.0]
		
	
}


bool HID::open()
{
	bool openRes = usb->open(VENDER_ID, PRODUCT_ID);
	if (!openRes)
		return false;

	setLEDs(false, false, false, false);

	unsigned char *outBuf = usb->getOutputByteBuffer();

	usb->clearOutputByteBuffer();
	outBuf[0] = 0x12;
	outBuf[1] = 0x00;
	outBuf[2] = 0x33;
	if (usb->write(outBuf, 3) <= 0)
		return false;

	return true;
}

////////////////////////////////////////////////
//	setLEDs
////////////////////////////////////////////////

bool HID::setLEDs(bool led1, bool led2, bool led3, bool led4)
{
	unsigned char *outBuf = usb->getOutputByteBuffer();

	usb->clearOutputByteBuffer();
	outBuf[0] = 0x11;
	outBuf[1] = 0x00;
	if (led1)
		outBuf[1] |= 0x10;
	if (led2)
		outBuf[1] |= 0x20;
	if (led3)
		outBuf[1] |= 0x40;
	//if (led4)
	outBuf[1] |= 0x80;
	if (usb->write(outBuf, 2) <= 0)
		return false;

	return true;
}



void HID::setRumble(){

	unsigned char pause[2]; //buffer de Pausa
	pause[0] = 21;
	pause[1] = 0;

	unsigned char on[2]; //buffer para la vibracion
	on[0] = 21;
	on[1] = 1;

	if (!vib && tRR > 0) //si el temporizador de la vibracion es mayor que 0, significa que tiene que vibrar
	{
		vib = true;
		usb->write(on, 2);
	}
	else if (tRR <= 0 && vib) //si estaba vibrando y el temporizador ha llegado a 0, se para la vibracion
	{
		vib = false;
		usb->write(pause, 2);
	}
}