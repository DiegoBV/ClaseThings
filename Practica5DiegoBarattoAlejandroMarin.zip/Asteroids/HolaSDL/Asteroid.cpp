#include "Asteroid.h"




Asteroid::~Asteroid()
{
}
