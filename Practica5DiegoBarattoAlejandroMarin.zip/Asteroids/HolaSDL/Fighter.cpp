#include "Fighter.h"

#include "Observer.h"

Fighter::~Fighter()
{
}
