#pragma once
#include <windows.h>
#include <commdlg.h>
#include <XInput.h>
#include <basetsd.h>
#pragma warning( disable : 4996 ) // disable deprecated warning 
#include <strsafe.h>
#pragma warning( default : 4996 )
#include "resource.h"

class BaseHID
{
protected:
	//Entradas
	short wButtons; //Botones (Utilizo Codificaci�n Xbox360)
	short wLastButtons; //Botones anteriores (Utilizo Codificaci�n Xbox360)
	float fLeftTrigger, fRightTrigger; //[0.0,1.0]
	float fThumbLX, fThumbLY, fThumbRX, fThumbRY; //[-1.0,1.0]
	float fThumbLXf, fThumbLYf, fThumbRXf, fThumbRYf; //[-1.0,1.0] Filtrado
	float T; //Perido de actualizaci�n
	float a; //Cte.Tiempo Filtro
				   //Salidas
	float fLeftVibration, fRightVibration; //[0.0,1.0] Salida
	float tLR = 0.0; //Tiempo que queda de vibraci�n en LR
	float tRR = 0.0; //Tiempo que queda de vibraci�n en RR
					 //Gestos
	short wButtonsDown; //EventosDown Botones (Codificaci�n Xbox360?)
	short wButtonsUp; //EventosUp Botones (Codificaci�n Xbox360?)
					  //EstadosRotacion Ro; //Estado del gesto de rotaci�n
	float tRo = 0.0; //Tiempo que queda para el gesto de rotaci�n
					 //Funciones virtuales que se deben reimplementar para cada mando.
	virtual bool LeeMando() = 0; //Lee estado del mando
	virtual void EscribeMando() = 0; //Escribe Feeback en mando
	virtual void Mando2HID() = 0; //Vuelca el estado del mando al HID


public:
	bool bConected; //Mando Conectado
					//Gets & Sets
	bool gBU(WORD bit); //Estado del Boton codificado en bit
	float gLT(); //Left Triger [0,1]
	float gRT(); //Right Triger [0,1]
	float gLJX(); //LeftJoyX [-1,1]
	float gLJY(); //LeftJoyY [-1,1]
	float gRJX(); //RightJoyX [-1,1]
	float gRJY(); //RightJoyY [-1,1]
	float gLJXf(); //LeftJoyXfiltered [-1,1]
	float gLJYf(); //LeftJoyYfiltered [-1,1]
	float gRJXf(); //RightJoyXfiltered [-1,1]
	float gRJYf(); //RigthJoyYfiltered [-1,1]
	void sLR(float cantidad, float tiempo); //LeftRumble [0,1]: cantidad [0,1], tiempo [0,inf]
	void sRR(float cantidad, float tiempo); //RightRumble [0,1]: cantidad [0,1], tiempo [0,inf]
											//Gestos
	bool BD(WORD Bit); //Boton Down codificado en Bit
	bool BU(WORD Bit); //Boton Up codificado en Bit
	bool GRLJ(); //Gesto de Rotaci�n del LeftJoy
	BaseHID(float t) //Constructor que recoge el periodo de muestreo
	{
		T = t / 1000; //Periodo de muestreo
		a = T / (0.1 + T); //Cte. de tiempo para filtros (depende de T)
	};
	~BaseHID() {};
	void Actualiza(); //Actualiza Mando2HID y HID2Mando.

};
void BaseHID::Actualiza()
{
	wLastButtons = wButtons; //Copia estado de botones
	bConected = LeeMando(); //Leo Mando
	if (bConected == true)
	{
		Mando2HID(); //Vuelco de Mando a HID normalizando
					 //Actualizo Gestos de entrada gen�ricos (entradas)
			//Genero Gesto de feedback (salida)
			EscribeMando(); //Escribo en Mando el feedback
	}
}

