#include "HIDXbox.h"

bool HIDXBox::LeeMando()
{
	if (!g_Controllers[i].bLockVibration)
	{
		// Map bLeftTrigger's 0-255 to wLeftMotorSpeed's 0-65535
		if (g_Controllers[i].state.Gamepad.bLeftTrigger > 0)
			g_Controllers[i].vibration.wLeftMotorSpeed = ((g_Controllers[i].state.Gamepad.bLeftTrigger +
				1) * 256) - 1;
		//else
		//g_Controllers[i].vibration.wLeftMotorSpeed = 0;

		// Map bRightTrigger's 0-255 to wRightMotorSpeed's 0-65535
		if (g_Controllers[i].state.Gamepad.bRightTrigger > 0)
			g_Controllers[i].vibration.wRightMotorSpeed = ((g_Controllers[i].state.Gamepad.bRightTrigger +
				1) * 256) - 1;
		//else
		//g_Controllers[i].vibration.wRightMotorSpeed = 0;
	}


	if ((g_Controllers[i].state.Gamepad.wButtons) &&
		(g_Controllers[i].lastState.Gamepad.wButtons == 0))
	{
		if (!(!g_Controllers[i].bLockVibration && g_Controllers[i].vibration.wRightMotorSpeed == 0 &&
			g_Controllers[i].vibration.wLeftMotorSpeed == 0))
			g_Controllers[i].bLockVibration = !g_Controllers[i].bLockVibration;
	}

	if ((wButtons & XINPUT_GAMEPAD_LEFT_SHOULDER) && !(wLastButtons & XINPUT_GAMEPAD_LEFT_SHOULDER)) {
		mouse_event(MOUSEEVENTF_LEFTDOWN, pt.x, pt.y, 0, NULL);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if (!(wButtons & XINPUT_GAMEPAD_LEFT_SHOULDER) && (wLastButtons & XINPUT_GAMEPAD_LEFT_SHOULDER)) {
		mouse_event(MOUSEEVENTF_LEFTUP, pt.x, pt.y, 0, NULL);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if ((wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER) && !(wLastButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER)) {
		mouse_event(MOUSEEVENTF_RIGHTDOWN, pt.x, pt.y, 0, NULL);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if (!(wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER) && (wLastButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER)) {
		mouse_event(MOUSEEVENTF_RIGHTUP, pt.x, pt.y, 0, NULL);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if ((wButtons & XINPUT_GAMEPAD_X) && !(wLastButtons & XINPUT_GAMEPAD_X)) {
		keybd_event(VK_HOME, 0x24, KEYEVENTF_EXTENDEDKEY | 0, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if (!(wButtons & XINPUT_GAMEPAD_X) && (wLastButtons & XINPUT_GAMEPAD_X)) {
		keybd_event(VK_HOME, 0x24, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if ((wButtons & XINPUT_GAMEPAD_B) && !(wLastButtons & XINPUT_GAMEPAD_B)) {
		keybd_event(VK_END, 0x23, KEYEVENTF_EXTENDEDKEY | 0, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if (!(wButtons & XINPUT_GAMEPAD_B) && (wLastButtons & XINPUT_GAMEPAD_B)) {
		keybd_event(VK_END, 0x23, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if ((wButtons & XINPUT_GAMEPAD_Y) && !(wLastButtons & XINPUT_GAMEPAD_Y)) {
		keybd_event(VK_PRIOR, 0x21, KEYEVENTF_EXTENDEDKEY | 0, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if (!(wButtons & XINPUT_GAMEPAD_Y) && (wLastButtons & XINPUT_GAMEPAD_Y)) {
		keybd_event(VK_PRIOR, 0x21, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if ((wButtons & XINPUT_GAMEPAD_A) && !(wLastButtons & XINPUT_GAMEPAD_A)) {
		keybd_event(VK_NEXT, 0x22, KEYEVENTF_EXTENDEDKEY | 0, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if (!(wButtons & XINPUT_GAMEPAD_A) && (wLastButtons & XINPUT_GAMEPAD_A)) {
		keybd_event(VK_NEXT, 0x22, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if ((wButtons & XINPUT_GAMEPAD_BACK) && !(wLastButtons & XINPUT_GAMEPAD_BACK)) {
		keybd_event(VK_ESCAPE, 0x1B, KEYEVENTF_EXTENDEDKEY | 0, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if (!(wButtons & XINPUT_GAMEPAD_BACK) && (wLastButtons & XINPUT_GAMEPAD_BACK)) {
		keybd_event(VK_ESCAPE, 0x1B, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if ((wButtons & XINPUT_GAMEPAD_START) && !(wLastButtons & XINPUT_GAMEPAD_START)) {
		keybd_event(VK_RETURN, 0x0D, KEYEVENTF_EXTENDEDKEY | 0, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if (!(wButtons & XINPUT_GAMEPAD_START) && (wLastButtons & XINPUT_GAMEPAD_START)) {
		keybd_event(VK_RETURN, 0x0D, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if ((wButtons & XINPUT_GAMEPAD_DPAD_UP) && !(wLastButtons & XINPUT_GAMEPAD_DPAD_UP)) {
		keybd_event(VK_UP, 0x26, KEYEVENTF_EXTENDEDKEY | 0, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if (!(wButtons & XINPUT_GAMEPAD_DPAD_UP) && (wLastButtons & XINPUT_GAMEPAD_DPAD_UP)) {
		keybd_event(VK_UP, 0x26, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if ((wButtons & XINPUT_GAMEPAD_DPAD_LEFT) && !(wLastButtons & XINPUT_GAMEPAD_DPAD_LEFT)) {
		keybd_event(VK_LEFT, 0x25, KEYEVENTF_EXTENDEDKEY | 0, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if (!(wButtons & XINPUT_GAMEPAD_DPAD_LEFT) && (wLastButtons & XINPUT_GAMEPAD_DPAD_LEFT)) {
		keybd_event(VK_LEFT, 0x25, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if ((wButtons & XINPUT_GAMEPAD_DPAD_DOWN) && !(wLastButtons & XINPUT_GAMEPAD_DPAD_DOWN)) {
		keybd_event(VK_DOWN, 0x28, KEYEVENTF_EXTENDEDKEY | 0, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if (!(wButtons & XINPUT_GAMEPAD_DPAD_DOWN) && (wLastButtons & XINPUT_GAMEPAD_DPAD_DOWN)) {
		keybd_event(VK_DOWN, 0x28, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if ((wButtons & XINPUT_GAMEPAD_DPAD_RIGHT) && !(wLastButtons & XINPUT_GAMEPAD_DPAD_RIGHT)) {
		keybd_event(VK_RIGHT, 0x28, KEYEVENTF_EXTENDEDKEY | 0, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if (!(wButtons & XINPUT_GAMEPAD_DPAD_DOWN) && (wLastButtons & XINPUT_GAMEPAD_DPAD_DOWN)) {
		keybd_event(VK_DOWN, 0x28, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);
		g_Controllers[i].vibration.wLeftMotorSpeed = 10035;
	}

	if (g_Controllers[i].vibration.wLeftMotorSpeed != 0) {
		timer++;
	}
	if (timer > 2) {
		g_Controllers[i].vibration.wLeftMotorSpeed = 0;
		timer = 0;
	}

	XInputSetState(i, &g_Controllers[i].vibration);
	return false;
}

void HIDXBox::EscribeMando()
{

}

void HIDXBox::Mando2HID()
{

}
