#pragma once
#include <Windows.h>
#include <XInput.h>
#include "BaseHID.h"

class HIDXBox : public BaseHID
{
private:
	CONTROLER_STATE XBox;
public:
	HIDXBox(float t) :BaseHID(t) {};
	bool LeeMando();
	void EscribeMando();
	void Mando2HID();
};

