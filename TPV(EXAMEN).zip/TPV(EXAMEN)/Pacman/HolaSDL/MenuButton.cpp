#include "MenuButton.h"


MenuButton::~MenuButton()
{
}

