#include "Bullets.h"



Bullets::Bullets()
{
}


Bullets::~Bullets()
{
}
