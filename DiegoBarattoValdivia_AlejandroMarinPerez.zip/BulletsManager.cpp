#include "BulletsManager.h"
#include "FillRectRenderer.h"
#include "BasicMotionPhysics.h"
#include "ExampleGame.h"

BulletsManager::~BulletsManager()
{
}

