#include "Observer.h"

Observer::Observer() {
	// TODO Auto-generated constructor stub

}

Observer::~Observer() {
	// TODO Auto-generated destructor stub
}

