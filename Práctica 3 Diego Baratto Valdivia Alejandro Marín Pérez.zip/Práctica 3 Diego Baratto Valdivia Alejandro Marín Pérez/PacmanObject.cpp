#include "PacmanObject.h"
#include "Game.h"


PacmanObject::PacmanObject()
{
}


PacmanObject::~PacmanObject()
{
}
