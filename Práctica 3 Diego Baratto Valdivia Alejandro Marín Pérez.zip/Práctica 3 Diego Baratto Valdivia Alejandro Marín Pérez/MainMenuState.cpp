#include "MainMenuState.h"


MainMenuState::MainMenuState()
{
}


MainMenuState::~MainMenuState()
{
}

void MainMenuState::handleEvent(SDL_Event& e) {
	GameState::handleEvent(e);
}

