#include "GameObject.h"
#include "Game.h"

GameObject::GameObject() {

}