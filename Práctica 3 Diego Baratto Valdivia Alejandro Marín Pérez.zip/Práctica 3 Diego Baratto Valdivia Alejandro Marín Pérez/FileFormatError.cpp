#include "FileFormatError.h"
FileFormatError::~FileFormatError()
{
}