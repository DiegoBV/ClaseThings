#include "GameOverState.h"



GameOverState::GameOverState()
{
}


GameOverState::~GameOverState()
{
}
